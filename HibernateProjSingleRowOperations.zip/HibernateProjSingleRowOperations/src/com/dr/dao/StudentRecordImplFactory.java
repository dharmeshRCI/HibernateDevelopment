package com.dr.dao;

public class StudentRecordImplFactory {
  
   public static StudentDAO getInstance() {
	   
	   return new StudentDAOImpl();
	   
   } 

}
