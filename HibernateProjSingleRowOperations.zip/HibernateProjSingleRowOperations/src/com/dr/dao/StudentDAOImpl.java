/**
 *     Separate DAO persistence class 
 *     that performs persistence operations 
 *  
 * */

package com.dr.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dr.domain.Address;
import com.dr.domain.StudentRecord;
import com.dr.utility.HibernateUtility;

public class StudentDAOImpl implements StudentDAO {


	@Override
	public void insertRecordOperation() {
		
		Session ses  = null;
	   
	    Transaction tx = null;
	    StudentRecord record = null;
	    boolean flag  = false;
	    // create session object to perform persistence operation 
	    ses = HibernateUtility.getSession();
		//entity class object
	    try {
	    
	    record  = new StudentRecord(); 
		
		//putting date(values) to the object 
	  //  record.setSeno(101);
		record.setSname("rakesh");
		record.setBranch("IT");
		record.setX_percentage(91.3F);
		record.setXii_percentage(82.3F);
	
		Address address  = new Address();
		address.setHno(26);
		address.setStreet("naharpura");
		address.setCity("ratlam");
		address.setAdrsHolder(record);
				
		tx = ses.beginTransaction();

  	    ses.save(record); 
  		
		
		flag  = true;
	    
	    }
		catch(HibernateException he)
	    {
	      he.printStackTrace();		
           flag = false;	    
 	    
	    }
	    
	    catch(Exception e)
	    {
			e.printStackTrace();
	        flag  = false;
	    }
	    
	    finally {
	    	
	    	if(flag)
	    	{
	    	   tx.commit();	
	    	  System.out.println("  Record Inserted Successfully");
	    	
	    	}
	    
	    	else {
	    		
	    	   tx.rollback();
	    	   System.out.println("Record Insertion Failed");
		    	
	    	}	    
	    
	    }
	    
	    
	}   

	@Override
	public void  fetchRecordOperation() {
		// TODO Auto-generated method stub
  
		Session ses  =  null;
		StudentRecord record  = null;
		
		ses  = HibernateUtility.getSession();
		
//		record   =  ses.get(StudentRecord.class,102);
		record   =  ses.load(StudentRecord.class,102);

        System.out.println("Student Details :    "+record);	
        HibernateUtility.closeSession(ses);	
	    HibernateUtility.closeSessionFactory();
	}

	@Override
	public void updateRecordOperation() {
		
		Session ses  = null;
		   
	    Transaction tx = null;
	    StudentRecord record = null,record1=null;
	    
	    boolean flag  = false;
	    // create session object to perform persistence operation 
	    ses = HibernateUtility.getSession();
		//entity class object
	    try {
	    
	    record1  = new StudentRecord(); 
		
	  record  = (StudentRecord)ses.get(StudentRecord.class,1001);  
	 	  		
		//putting date(values) to the object 
//	    record1.setSeno(1001);
		//record.setSname("neeraj");
	   record.setBranch("XY");
	   record1.setBranch("SS");  //exception   
		//record.setX_percentage(77.3F);
		//record.setXii_percentage(61.3F);
	
		tx = ses.beginTransaction();

       ses.update(record);
        ses.update(record1);

        //ses.saveOrUpdate(record);	
	 // record =   (StudentRecord)ses.merge(record) ;
	 // System.out.println(record);
		flag  = true;
	    
	    }
		catch(HibernateException he)
	    {
	      he.printStackTrace();		
           flag = false;	    
 	    
	    }
	    
	    catch(Exception e)
	    {
			e.printStackTrace();
	        flag  = false;
	    }
	    
	    finally {
	    	
	    	if(flag)
	    	{
	    	   tx.commit();	
	    	  System.out.println("  Record Updated Successfully");
	    	
	    	}
	    
	    	else {
	    		
	    	   tx.rollback();
	    	  System.out.println("Record Update Failed");
		    	
	    	}	    
	    
	    }
	    
	    HibernateUtility.closeSession(ses);
	    

	}

	

	@Override
	public void mergeRecordOperation() {

		Session ses  = null;
		   
	    Transaction tx = null;
	    StudentRecord record = null;
	    
	    boolean flag  = false;
	    // create session object to perform persistence operation 
	    ses = HibernateUtility.getSession();
		//entity class object
	    try {
	    
	    record  = new StudentRecord(); 
		
		//putting date(values) to the object 
	//    record.setSeno(102);
		record.setSname("aditya shukla");
		record.setBranch("home science");
		record.setX_percentage(76.3F);
		record.setXii_percentage(81.3F);
	
		tx = ses.beginTransaction();

        ses.merge(record);
		
		flag  = true;
	    
	    }
		catch(HibernateException he)
	    {
	      he.printStackTrace();		
           flag = false;	    
 	    
	    }
	    
	    catch(Exception e)
	    {
			e.printStackTrace();
	        flag  = false;
	    }
	    
	    finally {
	    	
	    	if(flag)
	    	{
	    	   tx.commit();	
	    	  System.out.println("  Record Merged Successfully");
	    	
	    	}
	    
	    	else {
	    		
	    	   tx.rollback();
	    	  System.out.println("Record Merge Failed");
		    	
	    	}	    
	    
	    }
	   
		
		
	}


	
	@Override
	public void deleteRecordOperation() {

		Session ses  = null;
		   
	    Transaction tx = null;
	    StudentRecord record = null;
	    
	    boolean flag  = false;
	    // create session object to perform persistence operation 
	    ses = HibernateUtility.getSession();
		//entity class object
	    try {
	    
	     record  = (StudentRecord)ses.get(StudentRecord.class,101); 
		// record  = new StudentRecord();
	    	
		//putting date(values) to the object 
	 //  record.setSeno(102);
        record.setSname("aditya shukla");
		record.setBranch("home science");
		record.setX_percentage(76.3F);
		record.setXii_percentage(81.3F);
          	
		tx = ses.beginTransaction();

        ses.delete(record);
        
		flag  = true;
	    
	    }
		catch(HibernateException he)
	    {
	      he.printStackTrace();		
           flag = false;	    
 	    
	    }
	    
	    catch(Exception e)
	    {
			e.printStackTrace();
	        flag  = false;
	    }
	    
	    finally {
	    	
	    	if(flag)
	    	{
	    	   tx.commit();	
	    	  System.out.println("  Record Deleted Successfully");
	    	
	    	}
	    
	    	else {
	    		
	    	   tx.rollback();
	    	  System.out.println("Record Deletion Failed");
		    	
	    	}	    
	    
	    }
	   
	    HibernateUtility.closeSession(ses);

	}


	
	
}
