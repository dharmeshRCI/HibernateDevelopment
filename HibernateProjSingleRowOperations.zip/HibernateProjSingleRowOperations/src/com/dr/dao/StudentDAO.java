/** common interface contract 
 *    for implementor DAO persistence class 
 * 
 *   
 * 
 * */


package com.dr.dao;



public interface StudentDAO {

	public void insertRecordOperation();   
	public void fetchRecordOperation();
	public void updateRecordOperation();
    public void deleteRecordOperation();
    public void mergeRecordOperation();
    
}
