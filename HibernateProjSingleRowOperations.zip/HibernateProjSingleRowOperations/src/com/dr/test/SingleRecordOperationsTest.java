package com.dr.test;

import com.dr.dao.StudentDAO;
import com.dr.dao.StudentRecordImplFactory;
import com.dr.utility.HibernateUtility;

public class SingleRecordOperationsTest {

	public static void main(String[] args) {


		StudentDAO dao  =  StudentRecordImplFactory.getInstance();
		dao.insertRecordOperation();
	//	dao.fetchRecordOperation();
//		dao.updateRecordOperation();
//	dao.mergeRecordOperation();
//	dao.deleteRecordOperation();
	
	HibernateUtility.closeSessionFactory();
	
	}

}
