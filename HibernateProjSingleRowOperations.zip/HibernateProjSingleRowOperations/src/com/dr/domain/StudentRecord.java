/**  (Domain/Entity/BO) class 
 *   that contains the data as  java object on which  
 *   we want to perform persistence operations
 * 
 *    Author : DharmeshRathod 
 *    Date : 1 3 August 2019
 * 
  */

package com.dr.domain;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.GenericGenerator;
import org.omg.CORBA_2_3.portable.OutputStream;

import com.sun.corba.se.spi.ior.Identifiable;

import lombok.Getter;
import lombok.Setter;

//class will map with DB table

@Getter
@Setter
@Entity
@Table(name = "STUDENT_RECORD")
public class StudentRecord   {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	 /*private properties that will map with 
	table columns
 	*/
	

    @Id
    @GenericGenerator(
        name = "assigned-sequence",
        strategy = "com.dr.domain.StringSequenceIdentifier",
        parameters = {
            @org.hibernate.annotations.Parameter(
                name = "sequence_name", value = "hibernate_sequence"),
            @org.hibernate.annotations.Parameter(
                name = "sequence_prefix", value = "CTC_"),
        }
    )
    @GeneratedValue(
        generator = "assigned-sequence",
        strategy = GenerationType.SEQUENCE)
	   @Column(name="STUDENT_ID")
        private String seno;
	
	@Column(name = "STUDENT_NAME")
    private String sname;
	
	@Column(name = "STUDENT_BRANCH")	
	private String branch;
	
	@Column(name = "X_PERCENTAGE")	
	private float x_percentage;
	
	@Column(name = "XII_PERCENTAGE")
    private float xii_percentage;
	
  
	
	private String tempPwd;



    	
	
}//entity class 
