package com.dr.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "STUDENT_ADDRESS")
public class Address {
 
       @Id
       @GeneratedValue(generator = "gen1")
    //   @GenericGenerator(name="gen1",strategy = "sequence",parameters =@Parameter(name="sequence",value = "address_seq"))       
       @Column(name="ADDRESS_ID")
       private int addressId;
       
       @Column(name="HOUSE_NO")
       private int hno;
       
       @Column(name="STREET")
       private String street;
       
       @Column(name="CITY")
       private String city;
       
       @OneToOne(targetEntity = StudentRecord.class,cascade = CascadeType.ALL)
       @JoinColumn(name="ADDRESS_HOLDER",referencedColumnName = "STUDENT_ID")
       private StudentRecord adrsHolder;	
	   
	
}
